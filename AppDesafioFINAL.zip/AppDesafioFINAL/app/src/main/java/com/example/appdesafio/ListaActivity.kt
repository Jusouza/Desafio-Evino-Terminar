package com.example.appdesafio

import androidx.appcompat.app.AppCompatActivity

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast

import java.util.ArrayList

import javax.security.auth.login.LoginException

class ListaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista)

        val usuarios = findViewById<View>(R.id.lvUsuarios) as ListView

        val usuario = preencherDados()

        val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, usuario)
        usuarios.adapter = arrayAdapter

        usuarios.onItemClickListener = AdapterView.OnItemClickListener {
            parent, view, position, id -> Toast.makeText(applicationContext,
                "Usuário: " + usuario[position], Toast.LENGTH_SHORT).show() }


    }

    private fun preencherDados(): ArrayList<String> {
        val dados = ArrayList<String>()
        dados.add("Juliana")
        dados.add("Idade: 18, Cidade: São Paulo")
        dados.add("Marcelo")
        dados.add("Idade: 20, Cidade: Araraquara")
        dados.add("Ana")
        dados.add("Idade: 21, Cidade: Osasco")
        dados.add("Paulo")
        dados.add("Idade: 24, Cidade: Guarulhos")
        dados.add("Roberto")
        dados.add("Idade: 25, Cidade: Pinheiros")
        dados.add("Rodrigo")
        dados.add("Idade: 42, Cidade: Campos do Jordão")
        dados.add("Danielle")
        dados.add("Idade: 41, Cidade: Monte Verde")
        dados.add("Enzo")
        dados.add("Idade: 7, Cidade: Interlagos")
        dados.add("Sofia")
        dados.add("Idade: 70, Cidade: Morumbi")
        dados.add("Matheus")
        dados.add("Idade: 54, Cidade: Perdizes")
        return dados
    }
    //logout


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }


    //no onResume da ActivityMain você coloca o seguinte


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menuLogout -> {
                try {
                    SharedPrefManager.getInstance(this)!!.logout()
                } catch (e: LoginException) {
                    e.printStackTrace()
                }

                finish()
                startActivity(Intent(this, LoginException::class.java))
                Toast.makeText(this, "Deseja realmente sair?", Toast.LENGTH_LONG).show()
            }
        }
        return true
    }
}
