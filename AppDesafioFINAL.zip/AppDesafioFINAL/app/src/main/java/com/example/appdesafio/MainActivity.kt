package com.example.appdesafio


import androidx.appcompat.app.AppCompatActivity

import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*


import java.util.ArrayList


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        et_email.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(content: Editable) {
                if (et_email.text == et_password.text) {
                    startActivity(Intent(applicationContext, ListaActivity::class.java))
                }

                val message = "E-mail inválido"

                et_email.error =
                        if (content.isNotEmpty()
                                && Patterns.EMAIL_ADDRESS.matcher(content).matches())
                            null
                        else
                            message
            }

            override fun beforeTextChanged(
                    content: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int) {
            }

            override fun onTextChanged(
                    content: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int) {
            }
        })

        et_password.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(content: Editable) {

                val message = "Senha inválida"

                et_password.error =
                        if (content.length > 5)
                            null
                        else
                            message
            }

            override fun beforeTextChanged(
                    content: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int) {
            }

            override fun onTextChanged(
                    content: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int) {
            }
        })


        bt_login.setOnClickListener {
            startActivity(Intent(applicationContext, ListaActivity::class.java))

        }

        fun alert(s: String) {
            Toast.makeText(this, s, Toast.LENGTH_LONG).show()
        }


    }}
